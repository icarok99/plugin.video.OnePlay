**Para instalar o addon oneplay primeiro é necessário instalar o addon script.module.resolveurl**

[**Baixar *script.module.resolveurl***](https://github.com/icarok99/OneRepo/raw/refs/heads/master/matrix/script.module.resolveurl/script.module.resolveurl.zip)

**Depois de instalado pode instalar o addon oneplay.**
